import pandas as pd

class RulesetFormatter:
    """Takes a JSON in the format of a dictionary and returns it as three separate tables 
    to be used in the SBOM scorer.

    Returns three pandas DataFrames in the order of repo rules, org rules and company rules

    Args: 
        ruleset_dict (Dict): License ruleset converted from JSON to a dictionary 
    """

    def __init__(self, ruleset_dict):

        self.repo_rules, self.org_rules, self.company_rules = self.ruleset_to_tables(ruleset_dict)

    def ruleset_to_tables(self, ruleset_dict):
        repo_rules = pd.DataFrame(ruleset_dict['repository-level'])
        org_rules = pd.DataFrame(ruleset_dict['organisation-level'])
        company_rules = pd.DataFrame(ruleset_dict['company-level'])
        return repo_rules, org_rules, company_rules