import json
import pandas as pd
import numpy as np

class SBOMScorer:
    """Takes an SBOM and compares it to a license rule set to determine how compliant it is.
    It returns the number of accepted licenses, number of rejected licenses (and their names),
    number of unknown licenses (and their names). 

    Args: 
        sbom (DataFrame): SBOM to be analysed 
        ruleset_path (Str): Path to the JSON ruleset 
    """

    def __init__(self, sbom, repo_rules, org_rules, company_rules):
   
        self.scores, self.rejected_components, self.unknown_components = self.check_sbom_license_compliance(
            sbom,
            repo_rules,
            org_rules,
            company_rules
        )

    def check_sbom_license_compliance(self, sbom, repo_rules, org_rules, company_rules):

        # Adding repository level data into the main table

        raw_data = sbom.merge(repo_rules, on="repo_name", how="left")

        # Adding organisation level data into the main table 

        columns_to_keep = ['repo_name',  'Name', 'Version', 'License', 'org_name', 'CopyrightNotice']
        raw_data = pd.concat(
        [
            raw_data.loc[raw_data["accepted"].notna(), :],
            raw_data.loc[raw_data["accepted"].isna(), columns_to_keep].merge(org_rules, on="org_name", how="left")
        ],
        ignore_index=True
        )

        # Adding company level data into the main table 
        raw_data[['accepted', 'rejected', 'copyright']] = raw_data[['accepted', 'rejected', 'copyright']].fillna(0)

        raw_data['accepted'] = raw_data['accepted'].apply(lambda x: np.where(x == 0, None, x))
        raw_data['rejected'] = raw_data['rejected'].apply(lambda x: np.where(x == 0, None, x))
        raw_data['copyright'] = raw_data['copyright'].apply(lambda x: np.where(x == 0, None, x))

        raw_data['accepted'] = raw_data['accepted'].astype(object)
        raw_data['rejected'] = raw_data['rejected'].astype(object)
        raw_data['copyright'] = raw_data['copyright'].astype(object)

        raw_data['accepted'] = raw_data['accepted'].apply(lambda x: company_rules['accepted'] if x is None else x)
        raw_data['rejected'] = raw_data['rejected'].apply(lambda x: company_rules['rejected'] if x is None else x)
        raw_data['copyright'] = raw_data['copyright'].apply(lambda x: company_rules['copyright'] if x is None else x)

        raw_data['CopyrightSplit'] = raw_data['CopyrightNotice'].str.lower().str.split(' ')

        # Using the rule set to score each component

        raw_data['licenseAccepted'] = raw_data.apply(lambda x: x['License'] in x['accepted'], axis=1)
        raw_data['licenseRejected'] = raw_data.apply(lambda x: x['License'] in x['rejected'], axis=1)
        raw_data['copyrightAccepted'] = raw_data.apply(lambda x: any(item in x['copyright'] for item in x['CopyrightSplit']) if isinstance(x['CopyrightSplit'], (list, tuple)) and x['CopyrightSplit'] is not None else False, axis=1)

        # Summarising the scores 

        raw_data['scoring'] = raw_data.apply(lambda x: 'Accepted' if x['licenseAccepted'] else 'Rejected' if x['licenseRejected'] else 'Accepted' if x['copyrightAccepted'] else 'Unknown', axis=1)

        rejected_components = raw_data.loc[raw_data['scoring'] == 'Rejected'][['repo_name','Name', 'License', 'CopyrightNotice']]
        unknown_components = raw_data.loc[raw_data['scoring'] == 'Unknown'][['repo_name','Name', 'License', 'CopyrightNotice']]

        summary = raw_data.groupby(['repo_name', 'scoring']).size().unstack(fill_value=0)

        summary['Rejected'] = summary.get('Rejected', 0) 
        summary['Unknown'] = summary.get('Unknown', 0) 
        summary['Accepted'] = summary.get('Accepted', 0) 

        return summary, rejected_components, unknown_components