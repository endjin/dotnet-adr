import argparse 
from sbom_analyser import SBOMScorer, SBOMWrangler, RulesetFormatter
import pathlib
import json 

def start():
    parser = argparse.ArgumentParser(description='Use your SBOM as a dataframe and your JSON ruleset to generate a score for the SBOM')
    parser.add_argument('sbom', type=str, help='the path to the JSON SBOM file')
    parser.add_argument('ruleset', type=str, help='the path to the JSON ruleset file')

    args = parser.parse_args()

    with open(args.ruleset, 'r') as file:
        json_ruleset = json.load(file)

    wrangled_SBOM = SBOMWrangler(args.sbom)
    rulesetFormatted = RulesetFormatter(json_ruleset)
    repo_rules, org_rules, company_rules = rulesetFormatted.repo_rules, rulesetFormatted.org_rules, rulesetFormatted.company_rules
    sbom_scores = SBOMScorer(wrangled_SBOM.cleansed_components, repo_rules, org_rules, company_rules)

    sbom_scoring, rejected_components, unknown_components = sbom_scores.scores, sbom_scores.rejected_components, sbom_scores.unknown_components

    current_output_path = pathlib.Path().resolve()
    print(sbom_scoring)
    print(f"The files 'sbom_analysis_summarised_scores.csv', 'sbom_analysis_rejected_components.csv' and 'sbom_analysis_unknown_components.csv' have been created and written to the current path: {current_output_path}")

    sbom_scoring.to_csv('sbom_analysis_summarised_scores.csv')
    rejected_components.to_csv('sbom_analysis_rejected_components.csv')
    unknown_components.to_csv('sbom_analysis_unknown_components.csv')