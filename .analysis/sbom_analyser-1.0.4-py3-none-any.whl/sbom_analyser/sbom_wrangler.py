import json
import pandas as pd

class SBOMWrangler:
    """A class that takes a path to an SBOM in JSON format and returns 
    a dataframe with the data extracted

    Args:
        path_to_sbom (Str): Path to the SBOM for wrangling 
    """

    def __init__(self, path_to_sbom):
        self.file = open(path_to_sbom, encoding="ISO-8859-1")
        self.sbom = json.load(self.file)

        self.sbom_name = self.sbom['Name']
        self.metadata = self.sbom['Metadata']
        self.components = self.sbom['Components']
        self.dependencies = self.sbom['Dependencies']

        self.metadata = self.normalize_data(self.metadata)
        self.components = self.normalize_data(self.components)

        if 'git_org' in self.metadata['Key'].unique():
            self.org_name = self.metadata.loc[self.metadata['Key'] == 'git_org', 'Value'].iloc[0]
        elif 'git_repo' in self.metadata['Key'].unique():
            self.org_name = self.metadata.loc[self.metadata['Key'] == 'git_repo', 'Value'].iloc[0]
            self.org_name = self.org_name.split('/')[0]


        self.cleansed_components = self.components[['Name', 'Copyright', 'License.Id', 'Version']].copy()
        self.cleansed_components = self.components.rename(columns={'License.Id': 'License', 'Copyright': 'CopyrightNotice'})

        self.cleansed_components['org_name'] = self.org_name
        self.cleansed_components['repo_name'] = self.sbom_name

    def normalize_data(self, data):
        """Normalizes a JSON object by flattening its nested structures 

        Args: 
            data (dict): A dictionary with the nested data 

        Returns:
            pandas.DataFrame: A DataFrame with the the data normalized 
        """
        return pd.json_normalize(data)